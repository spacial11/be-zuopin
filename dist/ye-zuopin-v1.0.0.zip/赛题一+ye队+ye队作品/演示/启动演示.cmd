@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

REM ============================================================
REM  启动演示：ye队作品 可验证多 Agent 编排
REM  自带 Python 运行时，双击即用，不需要安装任何东西。
REM ============================================================

set "HERE=%~dp0"
cd /d "%HERE%demo"

REM ---------- 1) 优先用自带的运行时 ----------
set "PY="
if exist "%HERE%demo\runtime\python.exe" (
  "%HERE%demo\runtime\python.exe" -c "import sys" >nul 2>nul
  if not errorlevel 1 set "PY=%HERE%demo\runtime\python.exe"
)

REM ---------- 2) 没有自带，就找系统里的 ----------
if not defined PY (
  where py >nul 2>nul && set "PY=py"
)
if not defined PY (
  for /f "delims=" %%P in ('where python 2^>nul') do (
    echo %%P | findstr /i "WindowsApps" >nul
    if errorlevel 1 if not defined PY set "PY=%%P"
  )
)
if defined PY (
  "%PY%" -c "import sys" >nul 2>nul
  if errorlevel 1 set "PY="
)

if not defined PY (
  echo.
  echo   [x] 找不到可用的 Python。
  echo       demo\runtime 目录是否被删掉了？
  echo       也可以自己装一个： https://www.python.org/downloads/
  echo.
  pause
  exit /b 1
)

REM ---------- 3) 选一个没被占用的端口 ----------
set "PORT="
for %%P in (8765 8766 8767 8768) do (
  if not defined PORT (
    netstat -ano | findstr /r /c:":%%P .*LISTENING" >nul
    if errorlevel 1 set "PORT=%%P"
  )
)
if not defined PORT set "PORT=8765"

echo.
echo   ye队作品 — 可验证的多 Agent 编排
echo   ------------------------------------
echo   Python : %PY%
echo   地址   : http://127.0.0.1:%PORT%
echo   关闭本窗口即停止演示。
echo.

REM ---------- 4) 等端口真的能连上，再开浏览器 ----------
start "" powershell -NoProfile -WindowStyle Hidden -Command ^
  "for($i=0;$i -lt 40;$i++){ try{ $c=New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1',%PORT%); $c.Close(); Start-Process 'http://127.0.0.1:%PORT%'; break } catch { Start-Sleep -Milliseconds 500 } }"

"%PY%" -m tidal_harness serve --demo --port %PORT%

echo.
echo   服务已停止。
pause
